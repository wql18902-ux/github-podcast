# 女娲 Skill 安装

这个下载包包含本机正在使用的 huashu-nuwa Skill 原件，不是已生成的人物角色。

1. 解压后保留完整的 huashu-nuwa/ 文件夹与 references/ 子目录。
2. 将整个文件夹导入支持 Skill 的 Agent。Codex 通常放在 ~/.codex/skills/huashu-nuwa/；其他 Agent 按其安装方式导入。若已有同名 Skill，先保留旧版再决定是否替换。
3. 在 Agent 中输入「用女娲蒸馏某个人的思维框架」，按原 Skill 的调研与确认流程执行。

此包原样保留本机 Skill 中的工具建议；联网搜索、并行 Agent 与工具可用性由使用者的 Agent 环境提供。包内不含 API Key、服务额度、人物调研成果或用户材料，也不会在下载时开始调研。

原作者：Huashu（花叔）。上游项目：https://github.com/alchaincyf/nuwa-skill
原件使用 MIT 许可，完整许可见 LICENSE。当前本机 SKILL.md 含本地适配；逐文件来源与 SHA-256 见下载包旁的 huashu-nuwa-manifest.json。本文件仅为 Sourcecast 添加的安装说明。
